package com.baekhwa.cho;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import javax.persistence.FetchType;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import com.baekhwa.cho.domain.dto.BoardDTO;
import com.baekhwa.cho.domain.dto.BoardInsertDTO;
import com.baekhwa.cho.domain.dto.MemberDTO;
import com.baekhwa.cho.domain.dto.MemberInsertDTO;
import com.baekhwa.cho.domain.dto.MemberUpdateDTO;
import com.baekhwa.cho.domain.dto.jpa.JpaBoardInsertDTO;
import com.baekhwa.cho.domain.entity.FileEntity;
import com.baekhwa.cho.domain.entity.JpaBoardEntity;
import com.baekhwa.cho.domain.entity.JpaBoardEntityRepository;
import com.baekhwa.cho.domain.entity.Prac.Cart;
import com.baekhwa.cho.domain.entity.Prac.CartRepository;
import com.baekhwa.cho.domain.entity.Prac.Category;
import com.baekhwa.cho.domain.entity.Prac.CategoryItem;
import com.baekhwa.cho.domain.entity.Prac.CategoryItemRepository;
import com.baekhwa.cho.domain.entity.Prac.CategoryRepository;
import com.baekhwa.cho.domain.entity.Prac.Item;
import com.baekhwa.cho.domain.entity.Prac.ItemRepository;
import com.baekhwa.cho.domain.entity.Prac.Member;
import com.baekhwa.cho.domain.entity.Prac.Orders;
import com.baekhwa.cho.domain.entity.Prac.OrdersRepository;
import com.baekhwa.cho.mybatis.mapper.BoardMapper;
import com.baekhwa.cho.mybatis.mapper.MemberMapper;
import com.baekhwa.cho.service.BoardJpaService;

@SpringBootTest
class BaekhwaProjectApplicationTests {

	@Autowired
	MemberMapper mapper;
	
	@Autowired
	BoardMapper boardMapper;
	
	//@Test
	void 더미데이터() {
		IntStream.rangeClosed(1, 200).forEach(i->{
			boardMapper.save(BoardInsertDTO.builder()
					.title("제목"+i).content("내용"+i).writer("test01@test.com")
					.build());
		});
	}
	
	///////////////////////////
	
	//@Test
	void 멤버삽입테스트() {
		int r=mapper.save(MemberInsertDTO.builder()
				.email("test02@test.com").name("test01").pass("1111")
				.build());
		//update 된 rows 수 리턴
		System.out.println(r+"개의 회원정보를 삽입하였습니다.");
	}
	//
	//@Test
	void 비밀번호수정() {
		MemberUpdateDTO dto=MemberUpdateDTO.builder()
				.no(2).pass("2222")
				.build();
		//먼저 대상이 존재하는지 체크
		Optional<MemberDTO> result= mapper.selectById(dto.getNo());
		if(result.isEmpty()) {
			System.out.println(">>>존재하지않는 회원");return;
		}
		
		mapper.update(dto);
	}
	
	////////////////////////////////////////////////////////
	
	@Autowired
	BoardJpaService service;
	
	@Autowired
	JpaBoardEntityRepository jbrepository;
	
	@Test
	void 파일적용저장테스트() {
		JpaBoardEntity entity = JpaBoardEntity.builder()
				.title("파일테스트 제목")
				.content("파일테스트 내용")
				.member(Member.builder().memberNo(14).build()) //작성자를 회원테이블과 연결
				.build();
				//파일 선택안한 게시글
				//files default 생성 List<FileEntity>
				
				//파일이 존재하면 파일 추가 코드
		entity.addFileEntity(FileEntity.builder()
					.url("/upload/file/")
					.orgName("img01.jpg")
					.newName("img01_220627100.jpg")
					.size(1024).build());
		jbrepository.save(entity);
	}
	
	//@Test
	void jpa데이터저장테스트() {
		IntStream.rangeClosed(1, 100).forEach(i->{
			
			JpaBoardInsertDTO dto=new JpaBoardInsertDTO();
			dto.setTitle("제목"+i);
			dto.setContent("내용"+i);
			//dto.setWriter("test01@test.com");
			
			//service.save(dto);
		});
	}
	
	@Autowired
	CategoryRepository categoryRepository;
	
	//@Test
	void 카테고리등록_테스트() {
		categoryRepository.save(Category.builder().name("식품").build());
	}
	
	@Autowired
	ItemRepository itemRepository;
	
	@Autowired
	CategoryItemRepository categoryItemRepository;
	
	//@Test
	void 상품등록_테스트() {
		CategoryItem entity = CategoryItem.builder()
				.category(categoryRepository.findById(2L).get())
				.item(Item.builder().name("감자").price(1000).stock(100).build())
				.build();
		categoryItemRepository.save(entity);
		//itemRepository.save(Item.builder().name("커피").price(2000).stock(1000).build());
		//System.out.println(item);
		//itemRepository.save(item);
	}

	//@Transactional
	//@Test
	void 해당카테고리_상품조회() {
		List<CategoryItem> result = categoryItemRepository.findAllByCategoryCategoryNo(2L);
		for(CategoryItem ci : result) {
			System.out.println(ci.getItem());
		}
	}
	
	//@Transactional //fetch = FetchType.LAZY 인 경우 필요
	//@Test
	void 카테고리이름검색해서_상품찾기() {
		Category result = categoryRepository.findByName("가전").orElseThrow();
		List<CategoryItem> categoryItems = result.getCategoryItems();
		for(CategoryItem ci : categoryItems) {
			System.out.println(ci.getItem());
		}
	}
	
	//카트 등록
	@Autowired
	CartRepository cartRepository; //JPA DAO
	
	//@Test
	void 카트등록() {
		Member m = Member.builder().memberNo(20).build(); //member 테이블 memberNo
		Cart cart = Cart.builder()
				.orders(Orders.builder().status("장바구니").build()
						.member(m))
				.item(Item.builder().itemNo(2).build())
				.count(1).orderPrice(2000)
				.build();
		cartRepository.save(cart);
	}
	
	@Autowired
	OrdersRepository ordersRepository;
	
	//@Transactional
	//@Test
	void 특정회원의_장바구니조회() {
		//Member m = Member.builder().memberNo(19).build();
		ordersRepository.findAllByMemberMemberNo(19).forEach(e->{
			e.getCarts().forEach(c->{
				System.out.println(c.getItem() + ":" + c.getCount() + ":" + c.getOrderPrice());
			});
		});
	}
	
	//@Transactional
	//@Test
	void 특정회원의_장바구니조회2() {
		//Member m = Member.builder().memberNo(19).build();
		ordersRepository.findAllByMemberMemberNoAndStatus(20, "장바구니").forEach(e->{
			e.getCarts().forEach(c->{
				System.out.println(c.getItem() + ":" + c.getCount() + ":" + c.getOrderPrice());
			});
		});
	}
}
