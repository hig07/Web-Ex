package com.baekhwa.cho.service;

import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.baekhwa.cho.domain.dto.jpa.JpaBoardInsertDTO;
import com.baekhwa.cho.domain.dto.jpa.JpaBoardUpdateDTO;
import com.baekhwa.cho.domain.dto.jpa.ReplyInsertDTO;

public interface BoardJpaService {

	void save(MultipartFile[] file, JpaBoardInsertDTO dto);

	void list(int pageNo, Model model);

	void detail(long no, Model model);

	void update(long no, JpaBoardUpdateDTO dto);

	void delete(long no);

	boolean reply(ReplyInsertDTO dto);

	//ModelAndView replies(long bno, ModelAndView mv);

	String replies(long bno, Model model);

	String fileUpload(MultipartFile file, String prevImgName);
}
