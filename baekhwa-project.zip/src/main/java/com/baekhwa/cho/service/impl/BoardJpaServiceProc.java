package com.baekhwa.cho.service.impl;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.catalina.core.ApplicationContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;

import com.baekhwa.cho.domain.dto.jpa.JpaBoardDetailDTO;
import com.baekhwa.cho.domain.dto.jpa.JpaBoardInsertDTO;
import com.baekhwa.cho.domain.dto.jpa.JpaBoardListDTO;
import com.baekhwa.cho.domain.dto.jpa.JpaBoardUpdateDTO;
import com.baekhwa.cho.domain.dto.jpa.ReplyInsertDTO;
import com.baekhwa.cho.domain.dto.jpa.ReplyListDTO;
import com.baekhwa.cho.domain.entity.FileEntity;
import com.baekhwa.cho.domain.entity.JpaBoardEntity;
import com.baekhwa.cho.domain.entity.JpaBoardEntityRepository;
import com.baekhwa.cho.domain.entity.ReplyEntityRepository;
import com.baekhwa.cho.service.BoardJpaService;
import com.baekhwa.cho.util.PageInfo;


@Service
public class BoardJpaServiceProc implements BoardJpaService {

	//jpa dao : repository 
	@Autowired
	private JpaBoardEntityRepository repository;
	
	
	@Override
	public void save(MultipartFile[] file,JpaBoardInsertDTO dto) {
		
		JpaBoardEntity entity=dto.toEntity();
		//저장 Entity로만 합니다.
		for(MultipartFile f :file) {
			if(!f.isEmpty()) {//파일이 존재하면
				//...파일 업로드and 파일테이블에 정보저장
				//String orgName=f.getOriginalFilename();
				
				//test.jpg-->sdfjnshkdfljskldfjslkf.jpg
				//String[] strs=orgName.split("[.]");// {"test","jpg"} //0,1 : 2
				//String extension="."+strs[strs.length-1];//.jpg
				//String newName=System.nanoTime()+extension;
				
				String url="/upload/";
				//workspace-> bin : src 빌드(컴파일) 생성
				ClassPathResource cprTemp=new ClassPathResource("static"+url+"temp");
				//String filePath="D:/java/spring/baekhwa-project/src/main/resources/static/upload";
				//String filePath="/home/ec2-user/src/root/";
				//System.out.println();
				try {
					File newFile=new File(cprTemp.getFile(), dto.getNewName());
					
					ClassPathResource uploadDir=new ClassPathResource("static"+url);
					File dest=new File(uploadDir.getFile(), dto.getNewName());
					newFile.renameTo(dest);
					System.out.println("temp -> upload 이동");
					
					
					entity.addFile(
							FileEntity.builder()
									.url(url)
									.size(f.getSize())
									.orgName(f.getOriginalFilename())
									.newName(dto.getNewName())
									.build()
							);//DB에 파일추가
				} catch (IllegalStateException | IOException e) {
					e.printStackTrace();
				}
			}
		}
		
		repository.save(entity);
		
	}

	
	@Override
	public void list(int pageNo, Model model) {//request scope 와 동일 : Model-> view까지 전달
		
		//repository.findAll().forEach(System.out::println);
		/*
		List<JpaBoardListDTO> result=repository.findAll() //List<JpaBoardEntity>
											.stream()     //Stream<JpaBoardEntity>
											.map(JpaBoardListDTO::new)//.map(e->new JpaBoardListDTO(e))
											.collect(Collectors.toList());
		model.addAttribute("list", result);
		*/
		///*
		int page=pageNo-1;//zero-based page index
		int size=10;//the size of the page to be returned
		Sort sort=Sort.by(Direction.DESC, "no");
		Pageable pageable=PageRequest.of(page,size,sort);
		
		//repository.findAll(pageable).stream().map(JpaBoardListDTO::new).collect(Collectors.toList());
		
		Page<JpaBoardEntity> pageObj=repository.findAll(pageable);
		int pageTotal=pageObj.getTotalPages();
		System.out.println(">>>>>>>>>>");
		PageInfo pageInfo=PageInfo.getInstance(pageNo, pageTotal);
		model.addAttribute("pi", pageInfo);
		model.addAttribute("list", pageObj.getContent().stream().map(JpaBoardListDTO::new).collect(Collectors.toList()));
		// */
		
		
		
		/*
		 * java 1.8 보다 하위버전에서는...
		List<JpaBoardEntity> r=repository.findAll();
		List<JpaBoardListDTO> list=new Vector<>();
		for(JpaBoardEntity e : r) {
			JpaBoardListDTO dto=new JpaBoardListDTO(e);
			list.add(dto);
		}
		model.addAttribute("list",list);
		*/
		/* 서버에서->페이지(veiw)로 넘길때는 Entity-> DTO로 매핑하여 페이지로... */
	}

	//@Transactional//지연로딩상태에서 파일정보를 읽기위해서..
	@Override
	public void detail(long no, Model model) {
		/*
		Optional<JpaBoardDetailDTO> result= repository.findById(no).map(new Function<JpaBoardEntity, JpaBoardDetailDTO>() {
			@Override
			public JpaBoardDetailDTO apply(JpaBoardEntity t) {
				// TODO Auto-generated method stub
				return null;
			}
			
		});
		*/
		//Optional<JpaBoardDetailDTO> result= repository.findById(no).map((e)->{return new JpaBoardDetailDTO(e);});
		//Optional<JpaBoardDetailDTO> result= repository.findById(no).map(e->new JpaBoardDetailDTO(e));
		//Optional<JpaBoardDetailDTO> result= repository.findById(no).map(JpaBoardDetailDTO::new);
		//model.addAttribute("detail", result);
		model.addAttribute("detail", repository.findById(no).map(JpaBoardDetailDTO::new).get());
		/*
		JpaBoardEntity entity=repository.findById(no).orElseThrow();
		JpaBoardDetailDTO dto=new JpaBoardDetailDTO(entity);
		model.addAttribute("detail", dto);
		*/
		/*
		JpaBoardEntity entity=repository.findById(no).orElseThrow();
		System.out.println("<<<<쿼리실행");
		model.addAttribute("detail", entity);
		*/
		
	}

	//수정처리
	
	@Transactional
	@Override
	public void update(long no, JpaBoardUpdateDTO dto) {
		//@Transactional 적용시
		repository.findById(no).map(e->e.update(dto));
		//repository.findById(no).map(e->{return e.update(dto);}));
		/////////////////////////////
		/*
		//@Transactional 적용않했을떄..
		//1.수정할대상을 확인 pk로(no)
		JpaBoardEntity entity=repository.findById(no).orElseThrow();
		System.out.println(">>수정대상:"+entity);
		//2.수정할데이터만 변경
		entity.update(dto);
		System.out.println(">>수정완료:"+entity);
		//3.수정된데이터를 저장하면 update가 실행
		repository.save(entity);
		*/
	}


	@Override
	public void delete(long no) {
		repository.deleteById(no);
		
	}
	
	@Autowired
	private ReplyEntityRepository replyEntityRepository;

	@Override
	public boolean reply(ReplyInsertDTO dto) {
		//댓글저장할려면?
		//게시글이 있어야 댓글을 쓸수있어요
		
		replyEntityRepository.save(dto.toEntity());
		
		
		return true;
	}

	@Override
	public String replies(long bno, Model model) {
		List<ReplyListDTO> result= replyEntityRepository.findAllByJpaBoardEntityNo(bno, Sort.by(Direction.DESC, "rno"))
				.stream().map(ReplyListDTO::new).collect(Collectors.toList());
		model.addAttribute("list", result); //
		return "view/boardjpa/reply/list";
	}


	@Override
	public String fileUpload(MultipartFile file, String prevImgName) {
		
		
		String orgName=file.getOriginalFilename();
		UUID uuid=UUID.randomUUID();
		String newName=uuid.toString()+orgName;
		ClassPathResource cpr=new ClassPathResource("static"+"/upload/temp");
		
		try {
			File location=cpr.getFile();//temp 폴더
			//이전에 업로드한 파일이 존재하면 삭제
			File prevImg=new File(location, prevImgName);
			if(prevImg.isFile())prevImg.delete();
			
			file.transferTo(new File(location , newName));//파일업로드
		} catch (IllegalStateException | IOException e) {
			e.printStackTrace();
		}
		
		return newName;
	}
	
	

}
