package com.baekhwa.cho.domain.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Entity
public class CategoryItem {
	
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Id
	long categoryItemNo;
	
	@JoinColumn(name = "categoryNo")
	@ManyToOne
	private Category category;
	
	@JoinColumn(name = "itemNo")
	@ManyToOne(cascade = CascadeType.ALL)//default fetch = FetchType.EAGER
	private Item item;
	//CascadeType
	//부모 엔티티가 영속화될 때 자식 엔티티도 같이 영속화되고, 
	//부모 엔티티가 삭제될 때 자식 엔티티도 삭제되는 등 
	//특정 엔티티를 영속 상태로 만들 때 연관된 엔티티도 함께 영속 상태로 전이되는 것을 의미

}
