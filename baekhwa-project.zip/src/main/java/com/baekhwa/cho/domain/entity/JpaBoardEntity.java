package com.baekhwa.cho.domain.entity;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Vector;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.baekhwa.cho.domain.dto.jpa.JpaBoardUpdateDTO;
import com.baekhwa.cho.domain.entity.Prac.Member;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


//@ToString //entity에는 안쓰는 것이 좋음. 연관관계 적용시 무한 루프 
@Builder
@AllArgsConstructor
@NoArgsConstructor//No default constructor for entity: db에서 결과를 매핑을 위해서 필요합니다.
@Getter
@EntityListeners(AuditingEntityListener.class)
@Entity
public class JpaBoardEntity {//jpa_board_entity

	@GeneratedValue(strategy = GenerationType.IDENTITY)//auto_increment
	@Id
	private long no;
	
	@Column(nullable = false)//not null
	private String title;
	@Column(columnDefinition = "text not null") //text : oracle-CLOB
	private String content;

	private int readCount;
	
	@CreationTimestamp // @EnableJpaAuditing 같은거 안 해줘도 
	private LocalDateTime createdDate;
	
	@UpdateTimestamp  // @EnableJpaAuditing 같은거 안 해줘도 
	private LocalDateTime updatedDate;
	
	//@EnableJpaAuditing를 사용해야 -> @CreatedDate @LastModifiedDate 활용 가능
	
	@Builder.Default
	@OneToMany(mappedBy = "jpaBoardEntity", cascade = CascadeType.ALL)
	private Collection<ReplyEntity> replies = new Vector<ReplyEntity>();
	
	@JoinColumn(name = "memberNo") //물리 db 이름은 member_no로 만들어짐
	@ManyToOne
	private Member member;
	
	//FileEntity 와 1:N 단방향설정
	@Builder.Default
	@JoinColumn(name = "bno") //FileEntity에 테이블에 생성되는 물리 FK명
	@OneToMany(cascade = CascadeType.ALL, fetch =FetchType.LAZY) //보드가 없으면 파일 db도 없다 -> 단방향
	List<FileEntity> fileEntities = new Vector<FileEntity>(); //파일 db는 접근 불가
	
	public JpaBoardEntity addFileEntity(FileEntity file) {
		fileEntities.add(file);
		return this;
	}
	
	public JpaBoardEntity removeFileEntity(FileEntity file) {
		fileEntities.remove(file);
		return this;
	}
	
	//수정처리 하기 위한 메서드
	public JpaBoardEntity update(JpaBoardUpdateDTO dto) {
		this.title=dto.getTitle();
		this.content=dto.getContent();
		return this;
	}
}
