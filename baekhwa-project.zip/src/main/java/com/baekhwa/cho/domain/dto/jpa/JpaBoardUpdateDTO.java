package com.baekhwa.cho.domain.dto.jpa;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@Setter
@Getter
public class JpaBoardUpdateDTO {
	
	//private long no;
	private String title;
	private String content;

}
