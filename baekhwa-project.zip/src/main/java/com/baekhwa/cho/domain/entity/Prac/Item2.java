package com.baekhwa.cho.domain.entity.Prac;

import java.util.List;
import java.util.Vector;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

/*@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Entity*/
public class Item2 {
	
	/*
	 * @Id
	 * 
	 * @GeneratedValue(strategy = GenerationType.IDENTITY) private long itemNo;
	 * 
	 * @Column(nullable = false) private String name;
	 * 
	 * @Column(nullable = false) private int price;
	 * 
	 * @Column(nullable = false) private int stock;
	 * 
	 * 
	 * @Builder.Default private List<Category> categorys = new Vector<Category>();
	 * 
	 * public Item2 addCategory(Category category) { categorys.add(category); return
	 * this; }
	 * 
	 * public Item2 removeCategory(Category category) { categorys.remove(category);
	 * return this; }
	 */
}
