package com.baekhwa.cho.domain.entity.Prac;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CartRepository extends JpaRepository<Cart, Long>{
	//프로그래머가 쿼리 메서드 규칙에 맞게 생성 가능
}
