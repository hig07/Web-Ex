package com.baekhwa.cho.domain.dto.jpa;

import com.baekhwa.cho.domain.entity.JpaBoardEntity;
import com.baekhwa.cho.domain.entity.Prac.Member;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@Getter
@Setter
public class JpaBoardInsertDTO {
	
	private String title;
	private String content;
	private String newName; //이미 업로드된 새로운 파일 이름
	private long memberNo;
	
	//field data db에 저장할 목적
	//db entity로만 저장해야합니다.
	//dto->entity 매핑이 필요해서 
	//메서드를 만들어서 처리하면 편리해요
	//메서드를 실행해서 entity객체를 얻어오도록 설계
	public JpaBoardEntity toEntity() {
		//실행되면 entity 객체를 얻어옴
		return JpaBoardEntity.builder()
				.title(title).content(content).member(Member.builder().memberNo(memberNo).build())
				.build(); //객체 만들어짐
	}
	
	//JpaBoardEntity e1=new JpaBoardEntity(0, title, content, writer, 0, null, null);
	//JpaBoardEntity e2=JpaBoardEntity.builder().build();

}
