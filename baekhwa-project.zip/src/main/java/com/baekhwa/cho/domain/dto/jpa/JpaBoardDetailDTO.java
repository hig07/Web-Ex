package com.baekhwa.cho.domain.dto.jpa;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import com.baekhwa.cho.domain.entity.JpaBoardEntity;

import lombok.Getter;


@Getter
public class JpaBoardDetailDTO {
	
	private long no;
	private String title;
	private String content;
	private int readCount;
	private LocalDateTime createdDate;
	private LocalDateTime updatedDate;
	
	private String email;//Member email적용
	
	//첨부파일정보
	private List<FileDTO> files;
	
	public JpaBoardDetailDTO(JpaBoardEntity e) {
		this.no = e.getNo();
		this.title = e.getTitle();
		this.content = e.getContent();
		this.readCount = e.getReadCount();
		this.createdDate = e.getCreatedDate();
		this.updatedDate = e.getUpdatedDate();
		//convert from List<FileEntity> to List<FileDTO>
		//LAZY 옵션에서는 e.getFiles() 실행되는 시점에서 파일에대한 쿼리가 실행됩니다.
		System.out.println(">>>파일쿼리가 실행되요");
		this.files=e.getFileEntities().stream()
				.map(FileDTO::new) // 생성자 FileDTO(FileEntity e) 존재하면 람다식으로 간결하게 가능
				.collect(Collectors.toList());
		
		email=e.getMember().getEmail();
	}
}
