package com.baekhwa.cho.domain.entity.Prac;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Vector;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import com.baekhwa.cho.domain.entity.JpaBoardEntity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Entity
public class Member {

	@Column(name = "no")
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private long memberNo;
	  
	@Column(nullable = false, unique = true) 
	private String email;
	  
	@Column(nullable = false) 
	private String name;
	  
	@Column(nullable = false) 
	private String pass;
	  
	@CreationTimestamp 
	private LocalDateTime createdDate;
	  
	@UpdateTimestamp 
	private LocalDateTime updatedDate;
	//양방향인 경우 그냥 쓰면 연계 테이블을 만들어버림 -> 외래키를 만들려고 한다
	//=> 속성을 이용해야 한다(mappedBy) => 읽기 전용, 기본 fetch lazy
	@OneToMany(mappedBy = "member") //주엔티티 order에 있는 객체 변수(필드명)	
	@Builder.Default
	List<Orders> orders = new Vector<Orders>();
	
	@OneToMany(mappedBy = "member")
	@Builder.Default
	List<JpaBoardEntity> boards = new Vector<JpaBoardEntity>();
}
