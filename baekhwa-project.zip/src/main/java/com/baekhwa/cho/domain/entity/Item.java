package com.baekhwa.cho.domain.entity;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@ToString(exclude = "categoryItems")
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Entity
public class Item {
	
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Id
	private long itemNo;
	@Column(nullable = false)
	private String name;
	@Column(nullable = false)
	private int price;
	@Column(nullable = false)
	private int stock;
	
	
	//읽기전용
	@OneToMany(mappedBy = "item")
	@Builder.Default
	private List<CategoryItem> categoryItems=new ArrayList<CategoryItem>();
	
	
	@OneToMany(mappedBy = "item")
	@Builder.Default
	List<Cart> carts=new ArrayList<Cart>();
	
	public Item addCategoryItem(CategoryItem categoryItem) {
		categoryItems.add(categoryItem);
		return this;
	}

}
