package com.baekhwa.cho.domain.entity.Prac;

import java.util.List;
import java.util.Vector;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Entity
public class Orders {

	 @Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY) 
	 private int orderNo;
	 
	 @Column(nullable = false) 
	 private String status;
	 
	 //FK 컬럼 생성
	 @JoinColumn(name = "memberNo", nullable = false) //name으로 원하는 컬럼명으로 설정
	 @ManyToOne //기본 fetch eager(한개 데이터만 들어오기에 즉시로딩 가능)
	 private Member member; //외래키는 연관 클래스를 이용하여 객체를 만든다
	 //cascade 생략의 의미는 수정이 불가하다는 의미, 읽기만 가능
	 
	 public Orders member(Member member) {
		 this.member= member; 
		 return this;
	 }
	 
	 @Builder.Default
	 @OneToMany(mappedBy = "orders") //지연로딩이 기본
	 private List<Cart> carts = new Vector<Cart>();
}
