package com.baekhwa.cho.domain.entity.Prac;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Vector;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Entity
public class Cart {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long cartNo;
	
	private int orderPrice;
	private int count;
	
	@JoinColumn(name = "orderNo", nullable = false)
	@ManyToOne(cascade = CascadeType.PERSIST) //cascade(보통 주엔티티에 사용), fetch 확인 필요
	private Orders orders;
	
	@JoinColumn(name = "itemNo", nullable = false)
	@ManyToOne(cascade = CascadeType.DETACH)
	private Item item;
}
