package com.baekhwa.cho.domain.dto.jpa;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import com.baekhwa.cho.domain.entity.JpaBoardEntity;

import lombok.Getter;

@Getter
public class JpaBoardListDTO {

	
	private long no;
	private String title;
	private int readCount;
	private LocalDateTime updatedDate;
	
	
	
	//생성자
	public JpaBoardListDTO(JpaBoardEntity e) {
		no=e.getNo();
		title=e.getTitle();
		readCount=e.getReadCount();
		updatedDate=e.getUpdatedDate();
		
	}
	/*
	 * .map(JpaBoardListDTO::new) 사용하고 싶다면
	 * public JpaBoardListDTO toJpaBoardListDTO(JpaBoardEntity e) { no = e.getNo();
	 * title = e.getTitle(); writer = e.getWriter(); readCount = e.getReadCount();
	 * updatedDate = e.getUpdatedDate();
	 * 
	 * return this; }
	 */
}
