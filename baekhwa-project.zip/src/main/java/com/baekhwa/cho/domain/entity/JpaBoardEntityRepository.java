package com.baekhwa.cho.domain.entity;

import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
                                                         //
//<엔티티클래스이름, pk에 해당하는 컬럼의 dataType>
@Repository //안써도 ㄱㅊ, 선택적 -> 단지 가독성을 위해 쓴다
public interface JpaBoardEntityRepository extends JpaRepository<JpaBoardEntity, Long>{
	//<엔티티 이름, PK의 제네릭 타입>
}
