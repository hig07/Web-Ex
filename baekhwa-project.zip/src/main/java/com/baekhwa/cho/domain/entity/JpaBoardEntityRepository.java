package com.baekhwa.cho.domain.entity;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
                                                         //
//<엔티티클래스이름, pk에 해당하는 컬럼의 dataType>
@Repository
public interface JpaBoardEntityRepository extends JpaRepository<JpaBoardEntity, Long>{
	
}
