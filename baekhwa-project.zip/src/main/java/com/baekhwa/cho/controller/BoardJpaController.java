package com.baekhwa.cho.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.baekhwa.cho.domain.dto.jpa.JpaBoardInsertDTO;
import com.baekhwa.cho.domain.dto.jpa.JpaBoardUpdateDTO;
import com.baekhwa.cho.domain.dto.jpa.ReplyInsertDTO;
import com.baekhwa.cho.domain.entity.FileEntity;
import com.baekhwa.cho.domain.entity.FileEntityRepository;
import com.baekhwa.cho.service.BoardJpaService;

@Controller
public class BoardJpaController {
	
	//서비스를 서브 컨트롤러라고 생각하면 된다
	@Autowired
	private BoardJpaService service;
	
	//jpa게시판으로 이동---화면에 list가 나와야해요
	@GetMapping("/boardjpa")
	public String list(Model model,@RequestParam(defaultValue = "1")  int pageNo) {
		//서비스에서 모델에게 메서드 처리할 예정(Util.List 필요X)
		//데이터 갖고가야죠:Model객체를 통해서 view에 데이터 전달
		service.list(pageNo, model); 
		//페이지 이동
		return "view/boardjpa/list";
	}
	
	//jpa게시판 글쓰기 페이지 이동
	@GetMapping("/boardjpa/write") //get : queryString parameter
	public String write() {
		return "view/boardjpa/write";
	}
	/*
	@PostMapping("/boardjpa/write")
	public String write(HttpServletRequest request) {//request 파라미터 data(post: form-data, get: queryString parameter) 매핑도 지원해줘요
		String title=request.getParameter("title");
		String content=request.getParameter("content");
		String writer=request.getParameter("writer");
		int no=Integer.parseInt(request.getParameter("no"));
		JpaBoardInsertDTO dto=new JpaBoardInsertDTO(title,content,writer);
		return "";
	}
	@PostMapping("/boardjpa/write")
	public String write(String title, String content, String writer) {//request 파라미터 data(post: form-data, get: queryString parameter) 매핑도 지원해줘요
		JpaBoardInsertDTO dto=new JpaBoardInsertDTO(title,content,writer);
		return "";
	}
	@GetMapping("/boardjpa/{aaa}") //aaa를 no로 매핑
	public String detail(@PathVariable("aaa") long no, Model model) {
		service.detail(no, model); //service에게 model을 넘겨주어 detail에 db 저장
		return "view/boardjpa/detail";
	}
	*/
	
	//글쓰기 버튼 클릭했을떄 db에 저장
	@PostMapping("/boardjpa/write") //MultipartFile file: 파라미터 명은 write.html의 input 태그 name=""과 같아야한다. 
	public String write(MultipartFile[] file, JpaBoardInsertDTO dto) {//request 파라미터 data(post: form-data, get: queryString parameter) 매핑도 지원해줘요
		//System.out.println(dto);
		service.save(file, dto);
		return "redirect:/boardjpa";
	}
	// /boardjpa/2 , /boardjpa/1 : /boardjpa/detail?no=1, /boardjpa/detail?no=2
	@GetMapping("/boardjpa/{no}")
	public String detail(@PathVariable long no, Model model) {
		service.detail(no, model); //service에게 model을 넘겨주어 detail에 db 저장
		return "view/boardjpa/detail";
	}
	
	@PutMapping("/boardjpa/{no}")
	public String update(@PathVariable long no,JpaBoardUpdateDTO dto) {
		service.update(no, dto);
		return "redirect:/boardjpa/"+no;
	}
	
	@ResponseBody
	@DeleteMapping("/boardjpa/{no}")
	public void delete(@PathVariable long no) {
		service.delete(no);
	}
	
	@ResponseBody
	@PostMapping("/boardjpa/{bno}/reply")
	public boolean reply(ReplyInsertDTO dto) {
		return service.reply(dto);
	}
	
	//상세페이지에서 페이지로딩 후 댓글 읽어오기
	@GetMapping("/boardjpa/{bno}/replies")
	public String replies(@PathVariable long bno, Model model) {
		return service.replies(bno, model);
	}
	
	@ResponseBody //문자열 리턴 -> success: function(result) 
	@PostMapping("/boardjpa/fileupload")
	public String fileUpload(MultipartFile file, String prevImgName) {
		return service.fileUpload(file, prevImgName);
	}
	
	@Autowired
	private FileEntityRepository fRopository;
	
	@Autowired
	private ResourceLoader resourceLoader;
	
	@ResponseBody
	@GetMapping(value = "/boardjpa/files/{fno}", produces =MediaType.APPLICATION_OCTET_STREAM_VALUE )
	public ResponseEntity<Resource> downloadFile(@PathVariable long fno, @RequestHeader("User-Agent") String userAgent) throws Exception {
		System.out.println(userAgent);
		if(userAgent.contains("Edg")) System.out.println("엣지 브라우저에서 실행중");
		else System.out.println("크롬 브라우저에서 실행중");
		//DB에서 파일정보 읽어오기
		FileEntity entity= fRopository.findById(fno).orElseThrow();
		
		Resource resource=resourceLoader.getResource("classpath:static/upload/"+entity.getNewName() );
		
		String fileName = new String(entity.getOrgName().getBytes("UTF-8"),"ISO-8859-1"); 
		
		return ResponseEntity.ok() //상태코드 설정 200 
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename="+fileName) 
				.header(HttpHeaders.CONTENT_LENGTH, entity.getSize()+"") 
				.body(resource);
		 
//		String downloadName = URLEncoder.encode(entity.getOrgName(), "utf-8");
//		HttpHeaders headers = new HttpHeaders();
//		headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + downloadName, null);
		//return new ResponseEntity<Resource>(resource, headers, HttpStatus.OK);
	}
}
