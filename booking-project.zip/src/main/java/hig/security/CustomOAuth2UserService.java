package hig.security;

import java.util.Map;
import java.util.Optional;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Service;

import hig.domain.entity.Member;
import hig.domain.entity.MemberRepository;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class CustomOAuth2UserService extends DefaultOAuth2UserService{

	private final MemberRepository memberRepository;
	private final PasswordEncoder passwordEncoder;
	
	@Override
	public OAuth2User loadUser(OAuth2UserRequest userRequest) throws OAuth2AuthenticationException {
		OAuth2User oAuth2User = super.loadUser(userRequest);
		//소셜 로그인 인증 완료 상태
		String registrationId = userRequest.getClientRegistration().getRegistrationId();
		System.out.println("registrationId: " + registrationId);
		//DB 저장
		return saveSocialUser(oAuth2User, registrationId);
	}

	private OAuth2User saveSocialUser(OAuth2User oAuth2User, String registrationId) {
		String name = null;
		String email = null;
		String sub = null;
		if(registrationId.equals("google")) {
//			Map<String, Object> userInfo = oAuth2User.getAttributes();
//			for(String key : userInfo.keySet()) {
//				System.out.println(key);
//				System.out.println(userInfo.get(key));
//			}
			name = oAuth2User.getAttribute("name");
			email = oAuth2User.getAttribute("email");
			sub = oAuth2User.getAttribute("sub");
		}
		//일반회원 또는 소셜회원 중 존재하는지 체크
		Optional<CustomUserDetails> result = memberRepository.findByEmail(email).map(CustomUserDetails::new);
		if(result.isPresent()) { //등록된 회원이면
			return result.get();
		}
		//가입이 안 된 회원은 소셜 정보로 회원가입
		Member entity =  memberRepository.save(Member.builder()
				.email(email).name(name).pass(passwordEncoder.encode(sub)).userIp("127.0.0.1")
				.isSocial(true)
				.build().addRole(MemberRole.USER));
		return new CustomUserDetails(entity);
	}
}
