package hig.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.web.SecurityFilterChain;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Configuration
public class SecurityConfig {
	
	//private final CustomAuthenticationFailureHandler failureHandler;
	//private final CustomAuthenticationSuccessHandler successHandler;
	//DaoAuthenticationProvider
	
	//RequiredArgsConstructor, final에 의해 Autowired가 필요없음
	private final CustomOAuth2UserService customOAuth2UserService;

    @Bean
    CustomAuthenticationFailureHandler failureHandler() {
    	return new CustomAuthenticationFailureHandler();
    }
    
    @Bean
    CustomAuthenticationSuccessHandler successHandler() {
    	return new CustomAuthenticationSuccessHandler();
    }
    
    @Bean
    SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.authorizeRequests(authorize ->
                authorize
	                .antMatchers("/", "/board/list", "/sign/signup", "/sign/signin").permitAll()// 인증필요없이 누구나 접근가능
	        		.antMatchers("/board/write").hasRole("USER")
	        		.antMatchers("/board/write").hasRole("ADMIN")
                    .antMatchers("/", "/common/**").permitAll()
                    .anyRequest().authenticated()
        );
        
        http.oauth2Login(oauth2Login->
        	oauth2Login
        		.loginPage("/signin")
        		.defaultSuccessUrl("/")
        		.userInfoEndpoint().userService(customOAuth2UserService)
        );
        
        http.formLogin(formLogin ->
                formLogin
                        .loginPage("/sign/signin")
                        .usernameParameter("email")
                        .passwordParameter("pass")
                        .failureUrl("/signin?errMsg")
                        .loginProcessingUrl("/sign/signin")
                        .defaultSuccessUrl("/")
                        .permitAll()
        );
        http.logout(logout -> 
        	logout.logoutSuccessUrl("/")
 		   .invalidateHttpSession(true)
        ); //default is "/login?logout".
        
        http.csrf();

        return http.build();
    }
    
	@Bean
    WebSecurityCustomizer webSecurityCustomizer() {
        return (web) -> web.ignoring().antMatchers(
                "/css/**"
        		, "/js/**"
        		, "/images/**"
        		, "/favicon.ico*"
        );
    }
}
