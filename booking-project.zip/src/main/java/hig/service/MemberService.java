package hig.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.ui.Model;

import hig.domain.dto.MemberInsertDTO;
import hig.domain.dto.SigninDTO;

public interface MemberService {

	String save(MemberInsertDTO dto, HttpServletRequest request);

	String signin(SigninDTO dto, HttpSession session, Model model);
}
