package hig.service.impl;

import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import hig.domain.dto.LoginDTO;
import hig.domain.dto.MemberInsertDTO;
import hig.domain.dto.SigninDTO;
import hig.domain.entity.Member;
import hig.domain.entity.MemberRepository;
import hig.security.MemberRole;
import hig.service.MemberService;
import hig.utils.EncryptUtils;

@Service
public class MemberServiceProcess implements MemberService {

	//DAO : jpa-Repository, mybatis-Mapper, jdbc-Connection(singleton으로 구성)
	@Autowired
	private MemberRepository repository;
	
	@Autowired
	PasswordEncoder pe;
	
	@Override
	public String save(MemberInsertDTO dto, HttpServletRequest request) {
		dto.passEncode(pe);
		dto.setUserIp(request.getRemoteAddr());//프록시서버(카페24) 또는 로드 밸런스를 통해 서버에 접속한경우 127.0.0.1
		
		//user롤 적용회원가입
		repository.save(dto.toMember().addRole(MemberRole.USER));
		return "redirect:/sign/signin";
	}

	@Override
	public String signin(SigninDTO dto, HttpSession session, Model model) {
		Optional<Member> result = repository.findByEmail(dto.getEmail());
		if(result.isPresent()) {
			//회원이 존재합니다.
			//패스워드 비교
			if(result.get().getPass().equals(EncryptUtils.encryptSHA256(dto.getPass()))) {
				//비밀번호일치
				//MemberDTO -> LoginDTO
				//LoginDTO loginfo=result.map(LoginDTO::new).get();
				session.setAttribute("loginfo", result.map(LoginDTO::new).get());
				return "redirect:/";
			}
		}
		//로그인실패시
		model.addAttribute("errMsg", "존재하지 않는 계정 또는 비밀번호가 상이 합니다.");
		return "/sign/signin";
	}
}