package hig.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Entity
public class BookEntity {
	//출발지, 도착지, 일정, 인원수
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private long bno; //book_no
	  
	@Column(nullable = false) 
	private String mno; //member_no
	  
	@Column(nullable = false) 
	private String cost;
	  
	@Column(nullable = false) 
	private String planeName;
	
	@Column(nullable = false) 
	private long size;
}
