package hig.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import hig.domain.dto.LoginDTO;
import hig.domain.dto.MemberInsertDTO;
import hig.domain.dto.SigninDTO;
import hig.service.MemberService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@Controller
public class MemberController {
	
	private final MemberService service;
	
	@GetMapping("/sign/signup")
	public String signup() {
		return "sign/signup";
	}
	
	@PostMapping("/signup")
	public String signup(MemberInsertDTO dto, HttpServletRequest request) {
		return service.save(dto, request);
	}
	
	@GetMapping("/sign/signin")
	public String login() {
		return "/sign/signin";
	}
	
	//로그인처리
	@PostMapping("/sign/signin") //파라미터 매핑을 위해 DTO객체에 setter 생성
	public String signin(SigninDTO dto,HttpSession session, Model model) {
		log.debug(">>> 로그인처리 : "+ dto);
		return  service.signin(dto, session, model); //성공시(인덱스), 실패시(로그인)
	}
	
//	@GetMapping("signout") //파라미터 매핑을 위해 DTO객체에 setter 생성
//	public String signout(HttpSession session) {
//		log.debug(">>> 로그아웃 처리");
//		session.removeAttribute("loginfo");
//		//session.invalidate();//모든세션 삭제
//		return  "redirect:/";
//	}
	
	@ResponseBody// boolean 결과 리턴 ajax -> success의 함수의 result로
	@GetMapping("signin-check")
	public boolean signinCheck(HttpSession session) {
		log.debug(">>> 로그인체크");
		LoginDTO loginfo = (LoginDTO) session.getAttribute("loginfo");
		log.debug(">>>loginfo : "+loginfo);
		if(loginfo == null) return false;
		return true;
	}
}
