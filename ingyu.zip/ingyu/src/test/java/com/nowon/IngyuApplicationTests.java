package com.nowon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IngyuApplicationTests {

	@Test
	void contextLoads() {
	}

}
