package com.mongodbTest;

import java.util.stream.IntStream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.mongodbTest.domain.MemberEntity;
import com.mongodbTest.domain.MemberEntityRepository;

@SpringBootTest
class MongodbTestApplicationTests {
	
	@Autowired
	MemberEntityRepository memberEntityRepository;
		
	//@Test
	void 시퀀스데이터저장() {
		MemberEntity memberEntity = new MemberEntity();
		
		memberEntity.setEmail("이메일!");
		
		memberEntityRepository.save(memberEntity);
	}

	@Test
	void 더미데이터입력테스트() {
		IntStream.rangeClosed(1, 10).forEach(i->{
			MemberEntity memberEntity=MemberEntity.builder()
					.email("test"+i+"@test.com")
					.build();
			memberEntityRepository.save(memberEntity);
		});
	}
}
